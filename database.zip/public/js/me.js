console.log("aliiiii !");
export {};
//# sourceMappingURL=me.js.map