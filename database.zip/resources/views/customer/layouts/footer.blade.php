<section>
  <!-- Footer -->
  <footer class="text-center z-show">
    <!-- Grid container -->
  
      <p>© 2025 Growvixo. Visas tiesības aizsargātas.</p>
    
  </footer>
  <!-- Footer -->
</section>
