// این کد یک پیام ساده را در کنسول چاپ می‌کند
console.log("Hello, Laravel + TypettttttttttttttScript!");
