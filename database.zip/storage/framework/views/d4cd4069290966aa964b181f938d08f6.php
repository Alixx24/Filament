<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title><?php echo $__env->yieldContent('title', 'HRM Project'); ?></title>
    <?php echo $__env->make('customer.layouts.head-tag', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>
<style>
     
</style>
<body class="bg-of-body">

    <div id="particles-js" class="style-particles" style=""></div>

    <?php echo $__env->make('customer.layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="hero-section">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <?php echo $__env->make('customer.layouts.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>



    <script src="https://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js"></script>
  
    <script>
        particlesJS('particles-js', {
            "particles": {
                "number": {
                    "value": 80
                },
                "color": {
                    "value": "#90A4C7"
                },
                "shape": {
                    "type": "circle"
                },
                "opacity": {
                    "value": 0.3,
                    "random": false
                },
                "size": {
                    "value": 3
                },
                "line_linked": {
                    "enable": true,
                    "distance": 150,
                    "color": "#90A4C7",
                    "opacity": 0.4,
                    "width": 1
                },
                "move": {
                    "enable": true,
                    "speed": 2
                }
            },
            "interactivity": {
                "events": {
                    "onhover": {
                        "enable": true,
                        "mode": "repulse"
                    }
                }
            }
        });
    </script>
    <script>
        const startBtn = document.getElementById('start');

        startBtn.addEventListener('click', function() {
            console.log(123);
            const infoSection = document.getElementById('info');
            const offset = 50; // ارتفاع هدر یا فاصله بالای صفحه
            const topPos = infoSection.getBoundingClientRect().top + window.scrollY - offset;

            window.scrollTo({
                top: topPos,
                behavior: 'smooth'
            });
        });
    </script>

</body>

</html>
<?php /**PATH C:\Users\ali\Desktop\project\fillament\resources\views/customer/layouts/master.blade.php ENDPATH**/ ?>