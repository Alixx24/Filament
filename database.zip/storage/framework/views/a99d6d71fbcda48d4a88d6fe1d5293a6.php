<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">


<link href="customer/css/styles.css" rel="stylesheet" />
<?php /**PATH C:\Users\ali\Desktop\project\fillament\resources\views/customer/layouts/head-tag.blade.php ENDPATH**/ ?>