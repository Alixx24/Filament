<section>
  <!-- Footer -->
  <footer class="text-center z-show">
    <!-- Grid container -->
  
      <p>© 2025 Growvixo. Visas tiesības aizsargātas.</p>
    
  </footer>
  <!-- Footer -->
</section>
<?php /**PATH C:\Users\ali\Desktop\project\fillament\resources\views/customer/layouts/footer.blade.php ENDPATH**/ ?>